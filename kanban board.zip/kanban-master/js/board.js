function Board(id, name, tasks) {
    this.id = id;
    this.name = name;
    this.tasks = tasks;
}